# Set J
## Number of Files : 103
## Number of Mentions : 605

### File names starts from doc_203.txt to doc_305.txt
## person names are marked up in the documents using \<person>...\</person> tags
