# Marked Documents
## Number of Files : 305
## Number of Mentions : 1817

### File names starts from doc_001.txt to doc_305.txt

## We are marking the person names for the articles got from the cricbuzz repository(Website for the cricket game).
  ### person names are marked up in the documents using \<person>...\</person> tags
  ### Eg. \<person>Virat Kohli\</person> is the captain of India
